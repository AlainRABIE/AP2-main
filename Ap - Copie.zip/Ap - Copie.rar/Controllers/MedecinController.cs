using ASPBookProject.Data;
using ASPBookProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace ASPBookProject.Controllers
{
    public class MedecinController : Controller
    {
        // Injection de dependance
        // private readonly IFakeDataService _fakeDataService;
        private readonly ApplicationDbContext _dbContext;
        // Sample Data
        // List<Instructor> InstructorsList = new List<Instructor>()
        //     {
        //         new Instructor() {
        //             InstructorId = 100,
        //         FirstName = "Maegan", LastName = "Borer",
        //         IsTenured=false, HiringDate=DateTime.Parse("2018-08-15"),
        //         Rank = Ranks.AssistantProfessor},
        //         new Instructor() {InstructorId = 200,
        //         FirstName = "Antonietta ", LastName = "Emmerich",
        //         IsTenured=true, HiringDate=DateTime.Parse("2022-08-15"),
        //         Rank = Ranks.AssociateProfessor},
        //         new Instructor() {InstructorId = 300,
        //         FirstName = "Antonietta", LastName = "Lesch",
        //         IsTenured=false, HiringDate=DateTime.Parse("2015-01-09"),
        //         Rank = Ranks.FullProfessor},
        //         new Instructor() {InstructorId = 400,
        //         FirstName = "Anjali", LastName = "Jakubowski",
        //         IsTenured=true, HiringDate=DateTime.Parse("2016-01-10"),
        //         Rank = Ranks.Adjunct}
        //     };

        // Constructor Injection
        public MedecinController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // GET: InstructorController
        public IActionResult Index()
        {
            return View(_dbContext.Medecins); // retourne la vue Index.cshtml
             Medecin = new ModelMedecin { Id = 1, Nom = "Jean Dupont", Email = "jean@exemple.com" },

        }


        public IActionResult DisplayAll()
        {
            // Par defaut la methode Index renvoie vers la vue Index
            // Si on souhaite retourner une vue avec un nom different
            // de celui de l'action on procede ainsi
            // return View("Index", _dbContext.Instructors); // retourne la vue Index.cshtml
            return View("Index");
        }

        public IActionResult ShowAll()
        {
            return RedirectToAction("Index", _dbContext.Medecins); // Redirection!
        }


        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Medecin Medecins)
        {
            // verification de la validite du model avec ModelState
            if (!ModelState.IsValid)
            {
                return View();
            }

            _dbContext.Medecins.Add(Medecins);
            _dbContext.SaveChanges();
            // return View("Index", _dbContext.Instructors); // retourne la vue Index.cshtml avec la nouvelle liste
            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Edit(int id)
        {

            // Return View au sein de l'action Edit retournera la vue Edit.cshtml
            Medecin? medec = _dbContext.Medecins.FirstOrDefault<Medecin>(ins => ins.MedecinId == id);

            if (medec != null)
            {
                return View(medec);
            }

            return NotFound();

        }

        [HttpPost]
        public IActionResult Edit(Medecin Medecins)
        {
            // verification de la validite du model avec ModelState
            if (!ModelState.IsValid)
            {
                return View();
            }

            Medecin? medec = _dbContext.Medecins.FirstOrDefault<Medecin>(ins => ins.MedecinId == Medecins.MedecinId);

            if (medec != null)
            {
                medec.Nom = Medecins.Nom;
                medec.Identifiant = Medecins.Identifiant;
                medec.Mots_de_passe = Medecins.Mots_de_passe;
                _dbContext.SaveChanges();

                // return View("Index", _dbContext.Instructors);
                return RedirectToAction("Index");
            }

            return NotFound();
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            // On recherche l'instructeur à supprimer avec l'id fourni en paramètre
            Medecin? medec = _dbContext.Medecins.FirstOrDefault<Medecin>(ins => ins.MedecinId == id);

            if (medec != null) // Si l'instructeur est trouvé
            {
                return View(medec); // On retourne la vue Delete.cshtml avec l'instructeur à supprimer
            }
            // Si l'instructeur n'est pas trouvé on retourne une erreur 404
            return NotFound();
            //return View();
        }

        [HttpPost]
        public IActionResult DeleteConfirmed(int MedecinId)

        {
            // On recherche l'instructeur à supprimer avec l'id fourni en paramètre
            Medecin? medec = _dbContext.Medecins.FirstOrDefault<Medecin>(ins => ins.MedecinId == MedecinId);


            if (medec != null) // Si l'instructeur est trouvé
            {
                _dbContext.Medecins.Remove(medec); // On le supprime de la liste
                _dbContext.SaveChanges(); // On sauvegarde les modifications
                // return View("Index", _dbContext.Instructors); // On retourne la vue Index.cshtml avec la nouvelle liste
                return RedirectToAction("Index");
            }
            // Si l'instructeur n'est pas trouvé on retourne une erreur 404
            return NotFound();
        }

        [HttpGet]
        public IActionResult ShowDetails(int id)
        {
            Medecin? medec = _dbContext.Medecins.FirstOrDefault<Medecin>(ins => ins.MedecinId == id);


            if (medec != null)
            {
                return View(medec);
            }

            return NotFound();
        }


    }
}
