using ASPBookProject.Data;
using ASPBookProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ASPBookProject.ViewModels; 

public class PatientEditViewModel
{
    public Patient? Patient { get; set; }
    public List<Antecedent>? Antecedents { get; set; }
    public List<Incompatibilite>? Incompatibilites { get; set; }
    public List<int> SelectedAntecedentIds { get; set; } = new List<int>();
    public List<int> SelectedIncompatibilitesId { get; set; } = new List<int>();
}

namespace ASPBookProject.Controllers
{
    public class PatientController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PatientController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var patients = await _context.Patients.ToListAsync();
            return View(patients);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var patient = await _context.Patients
                .Include(p => p.Antecedents)
                .Include(p => p.Incompatibilites)
                .FirstOrDefaultAsync(p => p.PatientId == id);

            if (patient == null)
            {
                return NotFound();
            }

            var viewModel = new PatientEditViewModel
            {
                Patient = patient,
                Antecedents = await _context.Antecedents.ToListAsync(),
                Incompatibilites = await _context.Incompatibilites.ToListAsync(),
                SelectedAntecedentIds = patient.Antecedents.Select(a => a.AntecedentId).ToList() ?? new List<int>(),
                SelectedIncompatibilitesId = patient.Incompatibilites.Select(a => a.IncompatibiliteId).ToList() ?? new List<int>()
            };

            return View(viewModel);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Patient patient)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }
            _context.Patients.Add(patient);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, PatientEditViewModel viewModel)
        {
            if (id != viewModel.Patient.PatientId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var patient = await _context.Patients
                        .Include(p => p.Antecedents)
                        .Include(p => p.Incompatibilites)
                        .FirstOrDefaultAsync(p => p.PatientId == id);

                    if (patient == null)
                    {
                        return NotFound();
                    }

                    // Mise à jour des propriétés du patient
                    patient.Age = viewModel.Patient.Age;
                    patient.Prenom = viewModel.Patient.Prenom;
                    patient.Nom = viewModel.Patient.Nom;

                    // Mise à jour des Incompatibilites
                    patient.Incompatibilites.Clear();
                    if (viewModel.SelectedIncompatibilitesId != null)
                    {
                        var selectedIncompatibilites = await _context.Incompatibilites
                            .Where(a => viewModel.SelectedIncompatibilitesId.Contains(a.IncompatibiliteId))
                            .ToListAsync();
                        foreach (var incompatibilites in selectedIncompatibilites)
                        {
                            patient.Incompatibilites.Add(incompatibilites);
                        }
                    }

                    // Mise à jour des antécédents
                    patient.Antecedents.Clear();
                    if (viewModel.SelectedAntecedentIds != null)
                    {
                        var selectedAntecedents = await _context.Antecedents
                            .Where(a => viewModel.SelectedAntecedentIds.Contains(a.AntecedentId))
                            .ToListAsync();
                        foreach (var antecedent in selectedAntecedents)
                        {
                            patient.Antecedents.Add(antecedent);
                        }
                    }

                    _context.Entry(patient).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PatientExists(viewModel.Patient.PatientId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            viewModel.Antecedents = await _context.Antecedents.ToListAsync();
            viewModel.Incompatibilites = await _context.Incompatibilites.ToListAsync();
            return View(viewModel);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var patient = await _context.Patients
                .Include(p => p.Antecedents)
                .Include(p => p.Incompatibilites)
                .FirstOrDefaultAsync(p => p.PatientId == id);

            if (patient == null)
            {
                return NotFound();
            }

            var viewModel = new PatientEditViewModel
            {
                Patient = patient,
                Antecedents = await _context.Antecedents.ToListAsync(),
                Incompatibilites = await _context.Incompatibilites.ToListAsync(),
            };

            return View(viewModel);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var patient = await _context.Patients.FindAsync(id);
            if (patient == null)
            {
                return NotFound();
            }

            _context.Patients.Remove(patient);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PatientExists(int id)
        {
            return _context.Patients.Any(e => e.PatientId == id);
        }
        [HttpGet]
        public async Task<IActionResult> ShowDetail(int id)
        {
            // Récupère le patient avec ses antécédents et incompatibilités
            var patient = await _context.Patients
                .Include(p => p.Antecedents)
                .Include(p => p.Incompatibilites)
                .FirstOrDefaultAsync(p => p.PatientId == id);

            // Vérifie si le patient existe
            if (patient == null)
            {
                return NotFound();
            }

            // Crée le ViewModel pour la vue
            var viewModel = new PatientEditViewModel
            {
                Patient = patient,
                Antecedents = patient.Antecedents?.ToList(),
                Incompatibilites = patient.Incompatibilites?.ToList()
            };

            // Retourne la vue detail avec le modèle
            return View("Details", viewModel); // Assurez-vous que le nom de la vue est correct
        }
    public async Task<IActionResult> ShowMedicament(int id)
{
    var medicament = await _context.Medicaments
        .Include(m => m.Antecedents)
        .Include(m => m.Ordonnances)
        .FirstOrDefaultAsync(m => m.MedicamentId == id);

    if (medicament == null)
    {
        return NotFound();
    }

    var viewModel = new MedicamentViewModel // Utilisez le bon nom de ViewModel ici
    {
        Medicament = medicament,
        Antecedents = medicament.Antecedents,
        Ordonnances = medicament.Ordonnances
    };

    return View("Disponible", viewModel); // Assurez-vous que la vue Details.cshtml existe
}

    }
}