using Microsoft.AspNetCore.Mvc;

namespace ASPBookProject.Controllers
{
    public class TestController : Controller
    {
        // GET: TestController
        public ActionResult Index()
        {
            return View();
        }

    }
}
