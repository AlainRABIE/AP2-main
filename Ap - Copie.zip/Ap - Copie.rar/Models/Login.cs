using System;

namespace ASPBookProject.Models;

public class ModelUtilisateur
{
    public int Id { get; set; }
    public string Nom { get; set; }
    public string Email { get; set; }
}

public class ModelProduit
{
    public int Id { get; set; }
    public string Nom { get; set; }
    public decimal Prix { get; set; }
}