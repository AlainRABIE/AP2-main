using System;

namespace ASPBookProject.Models;

public class Medecin
{
    public int MedecinId { get; set; }
    public required string Nom { get; set; }
    public required string Identifiant { get; set; }
    public required string Mots_de_passe { get; set; }
    public List<Ordonnance> Ordonnances { get; set; } = new();
}
