using System;
using ASPBookProject.Models;

namespace ASPBookProject.ViewModels // Assurez-vous que le namespace correspond
{
    public class Medecin // Renommez la classe ici
{
    public Medecin Medecins { get; set; }
}   
}