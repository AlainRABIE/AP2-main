using System;
using ASPBookProject.Models;

namespace ASPBookProject.ViewModels // Assurez-vous que le namespace correspond
{
    public class MedicamentViewModel // Renommez la classe ici
    {
        public Medicament Medicament { get; set; }
        public List<Antecedent> Antecedents { get; set; } = new();
        public List<Ordonnance> Ordonnances { get; set; } = new();
    }
}
